# Gitube v2

Prototype interactif pour GitHub Pages.

Fonctions :
- catalogue public ;
- recherche ;
- couleurs par produit ;
- stock ;
- commande ;
- espace propriétaire ;
- modification du prix à tout moment ;
- modification du stock et des couleurs ;
- ajout de produits et de photos ;
- gestion des commandes.

Important : cette version utilise `localStorage`. Elle est parfaite pour tester l'interface, mais les données ne sont pas partagées entre les appareils et le code admin n'est pas une vraie sécurité. Pour que les commandes envoyées par les visiteurs arrivent réellement dans ton espace privé depuis Internet, il faudra ensuite connecter une base de données/authentification.
